#!/usr/bin/env python3
"""evidence_audit.py — ferramenta determinística do tripé (exemplo R51).
Valida que uma evidência E-001 declarada existe de fato (fonte real) e
classifica a conclusão. Pura, sem estado, Pydantic-style estrita.

Uso: python3 evidence_audit.py --source <arquivo-glob> --claim <texto>
Saída JSON estrita; exit 0 só se a fonte comprovadamente existe.
"""
from __future__ import annotations

import argparse, glob, json, os, sys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True, help="caminho real (glob) que a evidência cita")
    ap.add_argument("--claim", required=True, help="afirmação que a evidência suporta")
    args = ap.parse_args()

    hits = [p for p in glob.glob(args.source, recursive=True) if os.path.exists(p)]
    verdict = "CONFIRMED" if hits else "UNKNOWN"
    note = "" if hits else "fonte não existe — NÃO declarar fato (princípio hefesto)"
    out = {
        "claim": args.claim,
        "source": args.source,
        "matches": len(hits),
        "verdict": verdict,
        "note": note,
    }
    print(json.dumps(out, ensure_ascii=False, indent=1))
    return 0 if hits else 2


if __name__ == "__main__":
    sys.exit(main())
