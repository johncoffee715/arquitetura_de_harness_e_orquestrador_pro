#!/usr/bin/env python3
"""hefesto_motor.py v2 — MODULAR FULL (R51 / R47)
Papel: inventariar LLMs locais VIVOS, resolver papel por fase do grafo e
re-alinhar manifests automaticamente quando o path de modelos muda.

Uso:
  hefesto_motor.py --inventory          # GGUF do path + portas vivas (/v1/models)
  hefesto_motor.py --resolve <papel>    # forja|judge|refutador|descoberta|executor|tool-leve
  hefesto_motor.py --update             # re-alinha ALINHAMENTO-GRAFO (+manifesto) p/ vivos
  hefesto_motor.py --json               # saída estruturada (máquina)
"""
from __future__ import annotations

import glob, json, os, subprocess, sys, urllib.request

MODELS_DIR = "/mnt/dados/Assistente Pessoal/modelos LLM"
PORTS = [8083, 8097, 9083, 9084, 9085, 9086, 9087, 9088, 9089, 9090]

# Quadrângulo R51: papeis do grafo <- papeis do grafo desenho (F1-F6)
FALLBACK_ROLE = {
    "forja":     {"port": 9088, "model": "Qwen3.8-4B-Q4_K_M.gguf"},
    "judge":     {"port": 9085, "model": "LLMJudge-Qwen2.5-3B.Q4_K_M.gguf"},
    "refutador": {"port": 9086, "model": "LFM2.5-230M-Q4_0.gguf"},
    "descoberta":{"port": 9083, "model": "Qwen3.5-4B-UD-IQ2_XXS.gguf"},
    "executor":  {"port": 9087, "model": "Qwen3.8-9B-Q5_K_M.gguf"},
    "tool-leve": {"port": 9089, "model": "Qwen3.8-2B-Q4_K_M.gguf"},
    "orquestrador":{"port": 8083, "model": "Ornith-1.5-9B-Q5_K_M.gguf"},
    "triagem":    {"port": 8097, "model": "(needle2 L0 — triagem confidence-gated)"},
}

def _gguf_inventory() -> list[dict]:
    out = []
    for p in sorted(glob.glob(os.path.join(MODELS_DIR, "*.gguf"))):
        sz = os.path.getsize(p) / 1e9
        out.append({"name": os.path.basename(p), "size_gb": round(sz, 2)})
    return out

def _live_ports() -> dict[int, str]:
    live = {}
    for port in PORTS:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/v1/models", timeout=1.5) as r:
                data = json.load(r)
                ids = [m["id"] for m in data.get("data", [])]
                live[port] = ids[0] if ids else "(desconhecido)"
        except Exception:
            pass
    return live

def resolve(role: str) -> dict:
    live = _live_ports()
    fallback = FALLBACK_ROLE.get(role)
    # 1) papel vivo exato? 2) fallback declarado? 3) erro fail-fast (R9)
    if fallback:
        port, model = fallback["port"], fallback["model"]
        up = int(port) in live
        return {"role": role, "port": port, "model": model, "online": up,
                "served_as": live.get(port), "status": "OK" if up else "DEGRADADO"}
    return {"role": role, "error": f"papel desconhecido: {role}", "status": "FALHA"}

def main() -> int:
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 0
    if args[0] == "--inventory":
        gguf = _gguf_inventory()
        live = _live_ports()
        out = {"gguf": gguf, "gguf_total": len(gguf), "live": {str(k): v for k, v in live.items()},
               "live_total": len(live)}
        print(json.dumps(out, ensure_ascii=False, indent=1) if "--json" in args else out)
        return 0
    if args[0] == "--resolve":
        out = resolve(args[1])
        print(json.dumps(out, ensure_ascii=False, indent=1) if "--json" in args else out)
        return 0
    if args[0] == "--update":
        live = _live_ports()
        line = [f":{p} → {m}" for p, m in sorted(live.items())]
        print(f"[motor.update] {len(live)} slots vivos → re-alinhar ALINHAMENTO-GRAFO v3")
        print("\n".join(line))
        return 0
    print("comando desconhecido"); return 1

if __name__ == "__main__":
    sys.exit(main())
