---
name: hefesto
description: "Doutrina unificada de absorção tecnológica PADRÃO GLOBAL (R51): QUADRÂNGULO Autofagia inicial → Helenização sequencial → Decomposição fractal → Forja HEFESTO, com tripé OBRIGATÓRIO .md/.py/.json quando a função é específica. Substitui professional-decompilation e .planning/autofagia."
mode: skill
origin: helenizado: "hefesto-creationist-v7-quadrangular-2026-08-26"
metadata:
  category: methodology
  version: 2.0.0
  date: 2026-08-26
  author: Gran-Mestre
  standard: "hefesto-tripe-r51"
---

# HEFESTO v2 — Doutrina Quadrangular (R51)

## Mandato
Produto do **modelo padrão R51**: toda feature/skill/subagent/tool/plugin é confeccionada por este quadrângulo e o resultado **deve impressionar o Panteão** (validadores) — só então avança no grafo desenho.

## O QUADRÂNGULO (ordem fixa)

```
1 AUTOFAGIA INICIAL ──► 2 HELENIZAÇÃO SEQUENCIAL ──► 3 DECOMPOSIÇÃO FRACTAL ──► 4 FORJA HEFESTO
      (absorver)                 (converter padrão)         (fragmentar stratagema)      (sintetizar+impressionar)
```

| Canto | Ação | Gate |
|---|---|---|
| **1 AUTOFAGIA** | absorção direta, quantitativa E qualitativa, do artefato/input/software — conhecimento tácito alheio entra inteiro; tabela proteína×ruído na ingestão + auditoria adversarial do original | G-A |
| **2 HELENIZAÇÃO** | conversão ao padrão OpenCode/harness componente-a-componente, sequencial (nome→descrição→contrato→código); um passo só avança com o anterior verde | G-H (parseável + global R2/R44 + frontmatter) |
| **3 DECOMPOSIÇÃO** | fragmentar o stratagema: decompor recursivamente a estratégia até primitivas atômicas — **fractal** — cada fragmento com ≥1 evidência E-001 | G-D |
| **4 FORJA** | fundir a matéria dos cantos 1-3 em ferramentas; **Panteão só libera passagem com impressão real** (R34/R37/R40) | G-F (evidência fresca executada + veredito) |

## O TRIPÉ OBRIGATÓRIO (quando uma função é muita específica)

`.md` — contrato semântico (quem raciocina/decide) · `.py` — motor determinístico (quem executa com precisão 100%: parsing/validação/automação) · `.json` — contrato estrito de máquina (`additionalProperties:false`, `required` completo, gerado de Pydantic, nunca à mão).
Regra: **se o `.md` sozinho não garante eficiência/determinismo → tripé é OBRIGATÓRIO**.

## TRIAD AUTOFÁGICA (embutida em todos os cantos)
- **Self-learning**: minerar conhecimento durante a absorção → decision-log
- **Self-scaffold**: gerar parsers/ganchos/estruturas como subproduto da forja (R44 global)
- **Self-healing**: detectar incoerência entre input do usuário/orquestrador/A2A e a realidade estrutural do código → **refutar o input** e auto-corrigir o ecossistema. *Exemplo real: atribuição "Drummond/1922" é incoerente — autofagia cultural como metáfora é de Oswald de Andrade, Manifesto Antropófago (1928).*

## CRIVO NO GRAFO DESENHO (obrigatório pós-forja)
O resultado passa pelos loops de brainstorm/refutação do grafo de 6 fases com subagentes frescos: **F1** descoberta · **F3** plano (cobertura/contratos) · **F5** macro (arquitetura/alinhamento contrato) · **F6** entrega (conformidade/qualidade). Cada gate: `PASSOU_CATEGORICO` por impressão real (R28/R40).

## AUDITORIA FINAL + BENCHMARK EMPÍRICO (sempre)
Gates G-D/G-A/G-H/G-F sobre o entregue; uso real medido (execução viva, testes RED→GREEN, métricas antes/depois); nota R34 **ancorada**; sem evidência → não declara "passou".

## MOTOR (usar sempre que precisar do inventário)
`python3 hefesto_motor.py --inventory --json` · `--resolve <forja|judge|refutador|descoberta|executor|tool-leve|orquestrador>` · `--update`

## Anti-padrões (proibidos)
Copiar literal / depender do original · fato sem evidência · score alto sem evidência · aprovação burocrática ("ok","passou") · recurso novo quando catálogo tem equivalente (R8) · scaffolding local (tudo global R2/R44).

## Output contract (ao fim, obrigatório)
```yaml
artifact: {name, sha256?, origin}
quadrangle: {autofagia: [proteína, ruído], helenização: [convertidos], decomposição: [fragmentos, E-001: n], forja: [entregues]}
tripé: {md, py, json} + testes RED→GREEN + result
crivo_grafo: {F1: ¬veredito, F3: ¬, F5: ¬, F6: ¬}
auditoria_final: {gates: ¬} · benchmark_empirico: {antes, depois, métricas}
memory: {vault_entries, lessons}
```
