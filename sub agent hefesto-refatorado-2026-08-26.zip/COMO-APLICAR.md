# HEFESTO — Guia de Aplicação Prática

> Como aplicar o pipeline Decompile → Digerir → Helenizar → Forjar em qualquer artefato.
> Casos reais citados vêm da sessão 2026-08-25 (opencode-dev).

## Quando invocar

Qualquer menção a absorver/adaptar tecnologia externa: repo, zip, binário, framework,
agente, doc. Triggers: "autofagia", "helenização", "decompilação", "absorve", "devora".

## Os 4 estágios na prática

### 1. DECOMPILAÇÃO — evidência antes de hipótese
- **Intake**: nunca modifique o original; trabalhe sobre cópia/extrato.
- Fontes válidas de evidência: código-fonte, `git show` de histórico, d.ts de pacotes,
  docs oficiais, benchmarks públicos.
- Classifique cada conclusão: `CONFIRMED` (vi o código) · `HIGH_CONFIDENCE`
  (múltiplas fontes convergem) · `PROBABLE/POSSIBLE` (marque como tal!) · `CONTRADICTED`.
- *Exemplo real*: descobrimos que o "Scope" do DeepSeek Harness NÃO é sandbox lendo a
  dissecação independente (12k commits) — refutou a premissa do documento original.
- **Gate G-D**: mapa estrutural com ≥1 evidência por afirmação central.

### 2. AUTOFAGIA — extrair essência, descartar ruído
| Extrair (proteína) | Descartar (ruído) |
|---|---|
| Invariantes, protocolos, gates de qualidade | Hardcodes de ambiente alheio |
| Padrões replicáveis | Cosmética, nomes de marca |
| Falhas DO original (vira lição) | Código morto |

- **Auditoria adversarial obrigatória**: procure fraudes/fraquezas no artefato
  (ex.: validador que auto-aprova sem evidência = antipadrão herdado e corrigido).
- **R8 Catálogo Primeiro**: grep no seu próprio codebase ANTES de decidir construir.
  *Exemplo real*: 3 propostas externas refutadas porque hooks/plugins/contexto já
  existiam nativamente — 3 greps de ~2 min economizaram semanas.

### 3. HELENIZAÇÃO — normatizar ao padrão OpenCode
Alvo por tipo: metodologia→`skills/<nome>/SKILL.md` · execução isolada→subagent `.md`
· reação a evento→hook idempotente · comportamento transversal→**plugin nativo**
· integração externa→MCP fail-safe · capacidade fim-a-fim→feature global (R44).
- Campos obrigatórios: `name`, `description`, `mode`, `origin:` (prefixo
  `absorvido:`/`helenizado:`), `metadata` (date, source).
- **Registro global R2/R44**: instale em `config/opencode/` — nunca /tmp nem sessão.
- *Exemplo real*: trajectory-export (dsh/hermes/MiMo) → plugin com hooks nativos;
  secure_runner R71 recuperado via `git show <sha>:path` → pacote generalizado.

### 4. FORJA — síntese com validação categórica
- TDD quando aplicável; temperatura 0 para código.
- **Panteão**: 4 validadores independentes (D/A/H/F), escala 0.0000001–100 (R34),
  nota SEMPRE com bugs concretos. Média >95 encerra; abaixo → refutação A2A (R40).
- Validador sem evidência → `UNKNOWN` + nota piso (antifraude).
- **Gate G-F**: evidência fresca de execução real (testes/lint rodados AGORA) +
  memória cerebral alimentada (vault `aprendizados/` + `log.md`).

## Métricas como apoio (uso contínuo)

Mantenha um scorecard vivo por ciclo (`dev-loop-metrics.jsonl`):
```
qualidade (testes/lint/types) · dívida (patches mortos, vendidos, stalls)
segurança (gates ativos) · cobertura (packages no CI)
```
Um ciclo só avança com gate categórico `PASSOU_CATEGORICO` + evidência fresca.
Meio-trabalho que quebra o build é pior que dívida visível e quantificada
(*exemplo real*: parity checker gerou manifesto de 51 símbolos em vez de
migração às cegas).

## Anti-padrões (nunca)

1. Copiar implementação literal / dependência do framework original
2. Fato sem evidência ou validação sem execução ("deve funcionar")
3. Score default alto sem evidência
4. Recurso novo quando equivalente existe no catálogo (R8)
5. Scaffolding preso em sessão local (violates R2/R44)

## Output contract

```yaml
artifact: {name, sha256?, origin}
decompilation: {structure_map, evidence_total, confirmed, unknown}
autophagy: {essence: [...], discarded_noise: [...], flaws_found_in_original: [...], gap_confirmed}
helenization: {targets: [{type, path}], registry_updated}
forging: {validators_scores: {D,A,H,F}, average, converged}
memory: {vault_entries: [...], lessons: [...]}
```

*Ciclo completo real desta semana: 16 commits, core 1097/0, 2 plugins globais,
1 pacote migrado de tarball vendado — todos passando pelos 4 gates.*
