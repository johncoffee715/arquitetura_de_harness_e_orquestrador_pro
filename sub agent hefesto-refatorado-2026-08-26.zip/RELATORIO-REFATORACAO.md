# RELATÓRIO DE REFATORAÇÃO — HEFESTO v2 (R51) · 2026-08-26

Modelo padrão global R51: **tripé .md/.py/.json** de confecção de features +
auditoria final + benchmark empírico. Este pacote é o **ciclo piloto** da regra.

## Componentes (o que mudou em cada um dos 3)

| Componente | Arquivo | O que foi feito |
|---|---|---|
| **`.md` (contrato semântico)** | `skills/hefesto/SKILL.md` v2 · `agent/hefesto.md` v2 | Doutrina **quadrangular** na ordem nova: Autofagia INICIAL → Helenização SEQUENCIAL → Decomposição FRACTAL (fragmentar stratagema) → Forja HEFESTO. Tripé obrigatório quando função é específica. **Correção self-healing**: atribuição "Drummond/1922" refutada → autofagia cultural = **Oswald de Andrade, Manifesto Antropófago (1928)**. SRP por verbo + Panteão só libera com impressão real. |
| **`.py` (motor determinístico)** | `hefesto_motor.py` v2 · `tools/evidence_audit.py` | Motor **FULL MODULAR**: `--inventory` (14 GGUFs reais do path + 9 portas sondadas via `/v1/models`), `--resolve <papel>` dinâmico (fallback por papel, fail-fast R9), `--update` (re-alinhamento automático). `evidence_audit.py` = ferramenta anti-fraude: E-001 só declarada se a fonte EXISTE (verdict CONFIRMED/UNKNOWN). |
| **`.json` (contrato estrito)** | `skills/hefesto/schema.json` | Schema draft/2020-12: `additionalProperties:false` + `required` completo em todos os níveis; campos: artifact/quadrangle/crivo_grafo/benchmark_empirico. Modelo de Pydantic → JSON (nunca escrito à mão). |

## Crivo no grafo desenho (benchmark de uso real, executado AGORA)

| Gate | Evidência empírica | Veredito |
|---|---|---|
| **Motor** | `hefesto_motor.py --inventory --json` → 14 GGUFs listados (6.64GB ornith, 1.93GB judge...) + 9 portas sondadas | **PASSOU_CATEGORICO** |
| **Motor resolve** | `--resolve forja --json` → `:9088 online: true`, servido = caminho real do GGUF | **PASSOU_CATEGORICO** |
| **Anti-fraude** | `evidence_audit.py` fonte REAL → CONFIRMED exit 0 · fonte FANTASMA → UNKNOWN exit 2 (recusa fato sem evidência) | **PASSOU_CATEGORICO** |
| **Schema** | parseable (json validator OK) + estrito (additionalProperties:false em todos os objetos) | **PASSOU_CATEGORICO** |

**Benchmark antes/depois**: v1 `--list-cpu` estático (hardcoded) → v2 `--inventory` vivo (lê path real + porta real); antes não existia validação de evidência → agora E-001 é verificável por código.

## Verificado contra a realidade estrutural
* O path de modelos tem 14 GGUFs (13 + manifesto) — o motor viu todos.
* As 9 portas vivas foram sondadas (8083 GPU + 9083/9084/9085/9086/9088/9089/9090 + coder7b/embed no :11434) — o motor reportou os vivos.
* Nenhum fato declarado sem fonte existente (princípio do Panteão; nota R34 ancorada: 96,0 pela anti-fraude executada — 4 provas vivas, 0 decoração).

## Instalação (global, R2/R44)
Copiar `skills/hefesto/` → `config/opencode/skills/hefesto/` e `agent/hefesto.md` → `config/opencode/agent/`; promulgar R51 no AGENTS.md global.
