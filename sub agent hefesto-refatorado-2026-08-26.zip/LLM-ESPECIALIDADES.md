# ESPECIALIDADES dos LLMs locais → tools/skills/subagents recomendados

> Inventário REAL (16-08-2026) de `/mnt/dados/Assistente Pessoal/modelos LLM/` + slots vivos.
> Base: manifesto_llm.json · ALINHAMENTO-GRAFO v2 · hefesto_motor.py --inventory.
> Regra R47: alinhamento automático do inventário ao grafo — re-resolver quando o path mudar.

| Modelo (GGUF) | Porta | Especialidade NATIVA | Papéis/tools que ele atende | Skills/subagents recomendados |
|---|---|---|---|---|
| **Ornith-1.5-9B-Q5_K_M** | :8083 GPU | raciocínio integrado, 262k nativo, tool-calling | Orquestrador Gran-Mestre · F2 contrato · F3 plano · F5 macro | `gran-mestre` (orquestração) · `hefesto` forja pesada |
| **Qwen3.5-4B-IQ2_XXS** | :9083 | prosa/GBNF, F2 criativo | Descoberta F1 · prosa de spec | brainstorm/ideias · redação de contratos |
| **Qwen3.5-0.8B** | :9084 | exploração barata, multimodal (mmproj R31) | F1 descoberta leve · visão (R31/R35) | `explore` leve · validação visual (screenshots) |
| **LLMJudge-Qwen2.5-3B** | :9085 | julgamento, temp baixa | F5/F6 auditoria e veredito | `sentinel-guard` (segurança) · validador pós-gates |
| **LFM2.5-230M** | :9086 | velocidade extrema (~400 t/s) | Loop refutação R42 · filtros rápidos | refutação acerto-e-erro em segundos |
| **Qwen3.8-2B** | :9089 | tool-calling nível 1.5 barato | Tool use · MCP call fino | subagent tool-leve · comandos curtos |
| **Qwen3.8-4B** | :9088 | forja de código (ctx 40k, tool-calling) | **Forja hefesto** · TDD small tasks | `hefesto` subagent (motor) · `sentinel-guard` |
| **Qwen3.8-9B** | :9087 | executor F4 (ctx 16k RAM-gated) | Execução/implementação | executor-code · TDD por task |
| **Ternary-Bonsai-8B** | :9090 | throughput/KV máximo (ternary) | Refutação A2A · brainstorm iterativo | `brainstorm` adversarial · alternativas rápidas |
| **Qwen3-1.7B** | cold | fallback leve | F4 fallback | reparo rápido |
| **Qwen3.8-27B-IQ1** | cold | maior criação de ideias | Fase 1 criativa (heavy) | concept generation (sob demanda) |
| **needle2 (L0)** | :8097 | triagem confidence-gated + regex determinístico (barato, L0) | **F1** gate de entrada · **F3** TDD-extract (expectativas de spec) · **F6** varredura de evidência E-001 · **R42** reflexo pattern-match | triagem de prompts · extração de expectativas de teste · verificação de evidência |

## Tripé por papel (R51)

| Papel | .md (decide) | .py (executa) | .json (contrato) |
|---|---|---|---|
| Forja hefesto | SKILL/agent | hefesto_motor.py · evidence_audit.py | schema.json |
| Auditoria | critérios | sentinel_guard.py | veredito |
| TDD task | spec.md | teste.py | input/saída |
| Memória | instrução | hooks/memory_keeper | índice |

## Regra de troca
`hefesto_motor.py --inventory --json` roda a cada ciclo: modelo novo/removido/offline →
re-resolve papéis → `--update` re-alinha este documento + ALINHAMENTO-GRAFO (R47/R27).
